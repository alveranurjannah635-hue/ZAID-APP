package id.zaid.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class ZaidClient implements ClientModInitializer {
    public static final String NAME = "ZAID CLIENT";
    public static KeyBinding openMenu;
    private static int cps;
    private static long cpsWindowStart = System.currentTimeMillis();

    @Override
    public void onInitializeClient() {
        Modules.registerDefaults();
        Config.load();
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.zaidclient.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.zaidclient"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                client.setScreen(new ClickMenuScreen());
            }
            Modules.tick(client);
            if (System.currentTimeMillis() - cpsWindowStart >= 1000) {
                cps = 0;
                cpsWindowStart = System.currentTimeMillis();
            }
        });

        HudRenderCallback.EVENT.register((draw, tickDelta) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.options.hudHidden || !Config.hudEnabled) return;
            int y = 8;
            draw.drawText(mc.textRenderer, Text.literal("ZAID CLIENT")
                    .styled(s -> s.withColor(0xFFFF3030).withBold(true)), 8, y, 0xFFFFFFFF, true);
            y += 12;
            draw.drawText(mc.textRenderer, "FPS: " + mc.getCurrentFps(), 8, y, 0xFFFFFFFF, true);
            y += 11;
            draw.drawText(mc.textRenderer, "CPS: " + cps, 8, y, 0xFFFFFFFF, true);
            y += 11;
            if (Config.showEnabledModules) {
                for (Module m : Modules.ALL) {
                    if (m.enabled) {
                        draw.drawText(mc.textRenderer, m.name, 8, y, 0xFFFF5555, true);
                        y += 10;
                    }
                }
            }
        });
    }

    public static void recordClick() { cps++; }
}
