package id.zaid.client;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public final class Modules {
    public static final List<Module> ALL = new ArrayList<>();
    private static double oldGamma = 1.0;

    private Modules() {}

    public static void registerDefaults() {
        ALL.clear();
        ALL.add(new Module("Sprint", "Automatically sprint while moving forward", null, null));
        ALL.add(new Module("Fullbright", "Raise client gamma while enabled", null, null));
        ALL.add(new Module("No Fall", "Reset fall distance locally (single-player/private worlds)", null, null));
        ALL.add(new Module("HUD", "Show FPS/CPS and enabled modules", null, null));
    }

    public static Module get(String name) {
        return ALL.stream().filter(m -> m.name.equals(name)).findFirst().orElse(null);
    }

    public static void tick(MinecraftClient mc) {
        if (mc.player == null) return;
        Module sprint = get("Sprint");
        if (sprint != null && sprint.enabled && mc.player.input.movementForward > 0) {
            mc.player.setSprinting(true);
        }
        Module fullbright = get("Fullbright");
        if (fullbright != null && fullbright.enabled) {
            mc.options.getGamma().setValue(16.0);
        } else {
            mc.options.getGamma().setValue(Config.gamma);
        }
        Module noFall = get("No Fall");
        if (noFall != null && noFall.enabled) {
            mc.player.fallDistance = 0;
        }
        Module hud = get("HUD");
        Config.hudEnabled = hud == null || hud.enabled;
    }
}
