# ZAID CLIENT

Client-side Fabric utility mod for **Minecraft Java 1.21.1**. Java 21 required.

## Included and working
- Black/red click menu (Right Shift), module toggle buttons
- Sprint while moving forward
- Fullbright through the local gamma setting
- No Fall by resetting local fall distance (use only in single-player/private worlds)
- HUD with FPS, CPS counter hook, and enabled-module list
- Local properties config at `.minecraft/config/zaidclient.properties`
- No telemetry, account/session access, token handling, remote config, or network requests

## Not included in this build
Kill Aura, Reach, Velocity, ESP, Tracers, X-Ray, Auto Clicker, Scaffold, Fly, and Speed are **not implemented** in this package. They are not silently represented as working toggles. Several of these alter multiplayer gameplay and should only be developed/tested for worlds or servers where the owner explicitly permits them.

## Build
1. Install JDK 21.
2. Install Gradle 8.8+ (or open this folder in IntelliJ IDEA and import `build.gradle`).
3. From the project folder run `gradle build`.
4. The mod jar will be in `build/libs/zaid-client-1.0.0.jar`.

## Install
1. Install Fabric Loader for Minecraft 1.21.1.
2. Put the built jar into `.minecraft/mods`.
3. Launch the Fabric 1.21.1 profile.
4. Press **Right Shift** in-game to open the menu.

## Notes
- The project source is provided; the jar is produced by building it locally.
- No anti-ban or anti-detection guarantee is made.
- If the game crashes, check `logs/latest.log` and verify Fabric API is installed.
